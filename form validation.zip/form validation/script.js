function toggleForm(){
    section=document.querySelector('section');
    container=document.querySelector('.container');
    container.classList.toggle('active');
    section.classList.toggle('active');
}
function clearErrors(){
    errors= document.getElementsByClassName('ferror');
    for(let item of errors)
    {
        item.innerHTML="";
    }
}
function seterror(id, error){
    element = document.getElementById(id);
    element.getElementsByClassName('ferror')[0].innerHTML= error;
}
function validateForm(){
    var returnval= true;
    clearErrors();

    //Name Validation
    var name= document.forms['myForm']['fname'].value;
    if(name==""){
        seterror("name", '**Name cannot be blank');
        returnval=false;
    }
    else if(name.length<3){
        seterror("name", '**Length of name is too short');
        returnval=false;
    }
    else if(!isNaN(name)){
       seterror("name", '**Name should contain alphabets only!');
       returnval=false;
    }

    //Email Validation
    var email= document.forms['myForm']['femail'].value;
    if(email==""){
        seterror("email", '**Email cannot be blank');
        returnval=false;
    }
    else if(email.length>30){
        seterror("email", '**Email length is too long');
        returnval=false;
    }

    //Phone Number Validation
    var phone= document.forms['myForm']['fphone'].value;
    if(phone==""){
        seterror("phone", '**Please, Enter your phone number');
        returnval=false;
    }
    else if(phone.length!=10){
        seterror("phone", '**Please, Enter 10 Digit Mobile Number');
        returnval=false;
    }

    //Age Validation
    var age= document.forms['myForm']['fage'].value;
    if(age==""){
        seterror("age", '**Age is a compulsory information!');
        returnval=false;
    }
    else if(age<18){
        seterror("age", '**Age cannot be less than 18');
        returnval= false;
    } 
    else if(age>60){
        seterror("age", '**Age cannot be more than 60');
        returnval= false;
    }

    //Password Validation
    var password= document.forms['myForm']['fpass'].value;
    if(password==""){
        seterror("pass", '**Create Password');
        returnval=false;
    }
    else if(password.length<4){
        seterror("pass", '**Password should be atleast 4 characters long');
        returnval=false;
    }
    
    //Confirm Password Validation
    var cpassword= document.forms['myForm']['fcpass'].value;
    if(cpassword==""){
        seterror("cpass", '**Enter Password value again.');
        returnval=false;
    }
    else if(cpassword != password){
        seterror("cpass", '**Password and Confirm password should match!');
        returnval=false;
    }

    return returnval;
}