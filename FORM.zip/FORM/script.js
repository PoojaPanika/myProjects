function seterror(id, error){
 element = document.getElementById(id);
 element.getElementsByClassName('formerror')[0].innerHTML = error;
}

function validateForm(){
    var returnval = true;
    var name =document.forms['myForm']['fname'].value;
    if(name.length<5){
        seterror("name","length of name is too short");
        returnval= false;
    }
    return returnval;
}