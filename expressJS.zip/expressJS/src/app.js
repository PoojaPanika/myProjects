const express = require("express");
const app = express();

//Routing in Express
app.get("/", (req, res) => {
   res.send("Hello from the express!!")
});
//about page
app.get("/about", (req, res) => {
    res.send("Hello from the About page!!")
 });
// listening request
app.listen(8000, () =>{
    console.log("listening the port at 8000");
});

