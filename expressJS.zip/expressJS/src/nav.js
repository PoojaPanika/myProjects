const express = require("express");
const app = express();
const port = 5000;
//Routing in Express
app.get("/", (req, res) => {
    //sending html data as res.
   res.write("<h1>Welcome to my Home page!!</h1>")
   res.write("<h1>Welcome to my new Home page!!</h1>")
   res.send();
});
//about page
app.get("/about", (req, res) => {
    res.send("Welcome to my About page!!")
});
//contact page
app.get("/contact", (req, res) => {
    res.send("Welcome to my Contact page!!")
});
//temp page
app.get("/temp", (req, res) => {
    //res.send("Welcome to my Temp page") //normal res.
    // sending json data as res.
    res.send([
        {
            id : 1,
            name : "pooja",
            contact : "12345678"
        },
        {
            id : 2,
            name : "panika",
            contact : "87654321"
        }
    ]);
 });
// listening request
app.listen(port, () =>{
    console.log(`listening the port at ${port}`);
});