//Creating server in express
/*const express = require("express");
const app = express();
const port = 8000;

app.get("/", (req, res) =>{
    res.send("here is my home page");
});
app.listen(port, ()=>{
    console.log(`listening to port at ${port}`)
}); */



const path = require("path");
const express = require("express");
const app = express();
const hbs = require("hbs");
//console.log(__dirname);
//const staticPath = path.join(__dirname, "../public");
const templatePath = path.join(__dirname, "../templates/views");
const partialsPath = path.join(__dirname, "../templates/partials");

//to set view engine
app.set("view engine", "hbs");
app.set("views", templatePath );
hbs.registerPartials(partialsPath);
// built-in middleware function (express.static())
//app.use(express.static(staticPath));

//template engine route
app.get("", (req,res)=>{
    res.render('index');
});

//Routing in Express
app.get("/", (req, res) => {
   res.send("Hello from the express!!")
});
//about page
app.get("/about", (req, res) => {
    res.render('about');
 });
app.get("/about/*",(req, res)=>{
    res.render('404', {
        errorcomment : "Opps this about us page couldn't be found!!!",
    });
});
//error page 404
app.get("*",(req, res)=>{
    res.render('404', {
        errorcomment : "Opps page couldn't be found!!!",
    });
});
// listening request
app.listen(8080, () =>{
    console.log("listening the port at 8080");
});





