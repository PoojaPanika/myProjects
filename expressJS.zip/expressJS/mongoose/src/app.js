const mongoose = require("mongoose");
const validator = require("validator");

//connection creation and creating a new database
mongoose.connect("mongodb://localhost:27017/pproject", { useNewUrlParser: true, useUnifiedTopology: true , useCreateIndex: true })
.then(()=> console.log("connection successfull......."))
.catch((err)=> console.log(err));

const playlistSchema = new mongoose.Schema({
    name: {
        type:String,
        required: true,
        uppercase: true,
        trim: true
    },
    age: {
       type: Number,
        validate(value){
           if(value<0){
               throw Error("Age count should not negative");
           }
       }

     /* validate:{
          validator:function(value){
              return value.length<0;
          },
          message: "Age count should not negative"
      }*/
    },
    email:{
        type: String,
        required:true,
        unique: true,
        validate(value){
            if(!validator.isEmail(value)){
                throw new Error("Email is invalid");
            }
        }
    },
    work: {
        type: String,
        required:true,
        lowercase:true,
       // enum:[ "frontend"]
    },
    active: Boolean
})

//Collection creation
const Playlist = new mongoose.model("Playlist", playlistSchema);

//create document or insert
/*const poojaPlaylist = new Playlist({
    name: "Pooja",
    age: 23,
    work: "backened",
    active: true
})

poojaPlaylist.save(); */

//create document or insert using async await func
const createDocument = async() =>{
    try{
        const poojaPlaylist = new Playlist({
            name: "        ManU          ",
            age: 24,
            work: "backened",
            active: true,
            email: "manumanu@gmail.com"
    })
    const result = await poojaPlaylist.save();
    console.log(result);
    }catch(err){
        console.log(err);
    }
}
createDocument();    


// Inserting multiple document
/*const createDocument = async() =>{
    try{
        const pPlaylist = new Playlist({
            name: "Ranjeet",
            age: 24,
            work: "backened",
            active: true
    })
    const poPlaylist = new Playlist({
        name: "Harsh",
        age: 22,
        work: "frontend",
        active: true
    })
    const pooPlaylist = new Playlist({
        name: "Tanishka",
        age: 21,
        work: "frontend",
        active: true
    })
    const poojPlaylist = new Playlist({
        name: "Richa",
        age: 24,
        work: "frontend",
        active: true
    })
    const poojaPlaylist = new Playlist({
        name: "Tanu",
        age: 23,
        work: "backened",
        active: true
    })
    //instead of save method using insertMany.
    const result = await Playlist.insertMany([pPlaylist, poPlaylist, pooPlaylist, poojPlaylist, poojaPlaylist]);
    console.log(result);
    }catch(err){
        console.log(err);
    }
}*/
//createDocument();

//read document using mongoose
const getDocument = async () =>{
    try{
    const result = await Playlist
    //.find({age: {$gt:23}})
    //.find({$and : [{work:"backened"}, {age:"24"}]})
    .find({age:"24"})
    .sort({name:-1})
    .select({name:1})
    //.countDocuments();
    //.limit(1)
    //.skip(2);
    console.log(result);
    }catch(err){
        console.log(err);
    }
}
//getDocument();

//Update document
const updateDocument = async (_id) =>{
    try{
        const result = await Playlist.findByIdAndUpdate({_id}, {
            $set : {
               name:"Tanishka" 
            }
        }, {
            new : true,
            useFindAndmodify : false
        });
        console.log(result);
    }catch(err){
        console.log(err);
    }  
}
//updateDocument("610b66ee9b00df2478d29b26");

//Delete the document
const deleteDocument = async (_id) =>{
    try{
       const result = await Playlist.findByIdAndDelete({_id});   
       console.log(result);
    }catch(err){
        console.log(err);
    }
}
//deleteDocument("610b66ee9b00df2478d29b28");