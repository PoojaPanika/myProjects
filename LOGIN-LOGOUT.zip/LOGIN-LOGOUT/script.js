function change() {
    document.getElementById("off").innerHTML = "LOGOUT";
    document.getElementById("image").style.visibility = 'visible';
    document.getElementById("form").style.visibility = 'hidden';
    document.getElementById("fbx").style.background = 'white';
} 

function clearErrors() {
    errors = document.getElementsByClassName('ferror');
    for (let item of errors) {
        item.innerHTML = "";
    }
}
function seterror(id, error) {
    element = document.getElementById(id);
    element.getElementsByClassName('ferror')[0].innerHTML = error;
}

form.addEventListener('onsubmit', (event) => {
    event.preventDefault();
    validateForm();
    
})



function validateForm() {
     var returnval= true;
     
     
     clearErrors();
    //Username Validation
    var name = document.forms['myForm']['fname'].value;
    if (name == "") {
        seterror("uname", '**Please, Enter Username');
        returnval = false;
    }
    else if (name.length < 3) {
        seterror("uname", '**Length of name should be 3 characters long');
        returnval = false;
    }
    else if (!isNaN(name)) {
        seterror("uname", '**Username should contain alphabets only!');
        returnval = false;
    }

    //Password Validation
    var password = document.forms['myForm']['fpass'].value;
    if (password == "") {
        seterror("pass", '**Please, Enter Password');
        returnval = false;
    }
    else if (password.length < 4) {
        seterror("pass", '**Password should be atleast 4 characters long');
        returnval = false;
    }
     
    
    return returnval ;
}

