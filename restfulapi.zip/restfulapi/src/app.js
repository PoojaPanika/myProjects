const express = require("express");
require("./db/conn");
const Student = require("./models/students");
const studentRouter = require("./routers/student");
const app = express();
const port = process.env.PORT || 8080;

app.get("/",(req,res)=>{
    res.send("Hello from the other sides by Pooja.");
})

app.use(express.json());
app.use(studentRouter);

//create a new students

/*app.post("/students",(req,res)=>{
    console.log(req.body);
    const user = new Student(req.body);
    user.save().then(()=>{
        res.status(201).send(user);
    }).catch((e)=>{{
        res.status(400).send(e);
    }})
    res.send("Hello from the other side.");
}) */


//create a new router
//const router = new express.Router();
//define the router
//router.get("/pooja", (req,res)=>{
//    res.send("HELLOOOOO GUYSSSSSSSS!!!");
//});
//register router
//app.use(router);


//create a new students using async await
/*app.post("/students", async(req,res)=>{
    try{
    const user = new Student(req.body);
    const createUser= await user.save();
    res.status(201).send(createUser);
    }catch(e){
    res.status(400).send(e);
    }
})*/




// read the data of registered students
/*app.get("/students", async(req,res)=>{
    try{
     const studentsData = await Student.find();
     res.send(studentsData);
    }catch(e){
     res.send(e);
    }
})*/


// read the individual student data using id
/*app.get("/students/:id", async(req,res)=>{
    try{
        const _id= req.params.id;
        const studentData = await Student.findById(_id);
        if(!studentData){
          return res.status(404).send();
        }else{
        res.send(studentData);
        }
    }catch(e){
        res.send(e);
    }
}) */

//update students by its id
/*app.patch("/students/:id", async(req,res)=>{
    try{
       const _id = req.params.id;
       const studentUpdate = await Student.findByIdAndUpdate(_id, req.body);
       res.send(studentUpdate)
    }catch(e){
       res.send(e);
    }
}) */


// delete students data by id
/*app.delete("/students/:id", async(req,res)=>{
    try{
    const deleteStudent = await Student.findByIdAndDelete(req.params.id);
    res.send(deleteStudent);
    }catch(e){
        res.status(400).send(e);
    }
})*/


app.listen(port, ()=>{
    console.log(`connection is setup at ${port}`);
})