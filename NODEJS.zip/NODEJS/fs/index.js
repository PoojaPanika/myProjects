// File System Synchronous programming

const fs= require('fs');

fs.writeFileSync('learn.txt', 'Learning NodeJS');

fs.appendFileSync('learn.txt', ' File System, Synchronous way (Curd operation).');

const read =fs.readFileSync('learn.txt', "utf-8");
  console.log(read);

fs.renameSync('learn.txt', 'read.txt');

fs.unlinkSync('read.txt');
