// Routing in NodeJS

const http = require("http");
const server = http.createServer((req, res)=>{
   // console.log(req.url);
   if(req.url == "/"){
    res.end("hello from the home side");   
   }
   else if(req.url == "/contact"){
    res.end("hello from the contactUS side");   
   }
   else if(req.url == "/about"){
    res.end("hello from the aboutUS side");   
   }
   else {
       res.writeHead(404, {"Content-type": "text/html"});
       res.end("<h1> 404 error pages. Page doesn't exist!! </h1>");   
   }
});
server.listen(3000, "127.0.0.1",()=>{
   console.log('listening to the port no 3000');
}); 