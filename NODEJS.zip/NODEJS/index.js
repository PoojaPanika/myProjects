
//Exporting here my own module (ImportExport Folder)
 /*const{add, sub, mult, div, mod} = require('./ImportExport/create.js');
console.log(add(15,5));
console.log(sub(10,5));
console.log(mult(15,4));
console.log(div(4,2));
console.log(mod(9%2));


// checking nodemon npm module
/*const data = "hii, this is Pooja Panika. What's your name?";
console.log(data); */

// checking API

const http = require("http");
const fs = require("fs");
const server = http.createServer((req, res)=>{
const data = fs.readFileSync(`${__dirname}/API/api.json`, "utf-8");
    const objData = JSON.parse(data);
   if(req.url == "/"){
    res.end("hello from the home side");   
   }
   else if(req.url == "/contact"){
    res.end("hello from the contactUS side");   
   }
   else if(req.url == "/about"){
    res.end("hello from the aboutUS side");   
   }
   else if(req.url =="/user"){   
    res.end(objData[0].city);
   }
   else {
    res.writeHead(404, {"Content-type": "text/html"});
    res.end("<h1> 404 error pages. Page doesn't exist!! </h1>");   
   }
});
server.listen(3000, "127.0.0.1",()=>{
   console.log('listening to the port no 3000');
}); 




