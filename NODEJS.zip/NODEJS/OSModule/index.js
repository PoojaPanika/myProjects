// OS Module
const os= require('os');

console.log(os.arch());                           //x64
const freeMemory = os.freemem();                 
console.log(`${freeMemory/1024/1024/1024}`);      //0.9042892456054688
const totalMemory = os.totalmem();                
console.log(`${totalMemory/1024/1024/1024}`);     //3.8883590698242188
console.log(os.hostname());                       //LAPTOP-BP2333GN
console.log(os.platform());                       //win32
console.log(os.tmpdir());                         //C:\Users\POOJAP~1\AppData\Local\Temp
console.log(os.type());                           //Windows_NT
