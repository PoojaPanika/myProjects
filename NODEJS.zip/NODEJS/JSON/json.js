// JSON in NodeJS
   // creating an object
   const person ={
    name: 'Pooja Panika',
    age: '23',
    qualification: 'b.tech',
    channel : 'Pooja Panika Music'
};
//converting this obj into JSON
const jsonData = JSON.stringify(person);
console.log(jsonData);
//converting this jsonData into object
const objData = JSON.parse(jsonData);
console.log(objData);
//again converting this objData into JSON
const jsonnData = JSON.stringify(objData);
console.log(jsonnData);