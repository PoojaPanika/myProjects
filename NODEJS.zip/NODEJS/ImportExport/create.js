// Creating my own module here

const add = (a,b)=>{
    return a+b;
}
const sub = (a,b)=>{
    return a-b;
}
const mult = (a,b)=>{
    return a*b;
}
const div = (a,b)=>{
    return a/b;
}
const mod = (a,b)=>{
    return a%b;
}



module.exports ={add, sub, mult, div, mod};