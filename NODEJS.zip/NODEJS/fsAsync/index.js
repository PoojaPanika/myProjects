// File System Asynchronous programming

const fs = require('fs');
/*
fs.writeFile('learn.txt',"Learning File System Module", (err)=>{
    console.log('file is created');
});
fs.appendFile('learn.txt'," And Practicing Asynchronous programming (CURD Operation).", (err)=>{
   console.log('file is updated');
});
fs.rename('learn.txt','read.txt', (err)=>{
   console.log('file is renamed');
});  
fs.readFile('read.txt', "utf-8", (err, data)=>{
   console.log(data);
}); */
fs.unlink('read.txt', (err)=>{
    console.log('file deleted');
});